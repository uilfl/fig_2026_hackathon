CREATE TABLE public.contract_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  version integer NOT NULL,
  snapshot jsonb NOT NULL,
  diff jsonb NOT NULL DEFAULT '[]'::jsonb,
  signed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, version)
);
GRANT SELECT, INSERT ON public.contract_versions TO authenticated;
GRANT ALL ON public.contract_versions TO service_role;
ALTER TABLE public.contract_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own versions read" ON public.contract_versions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own versions insert" ON public.contract_versions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);