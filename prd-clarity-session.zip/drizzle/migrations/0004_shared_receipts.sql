CREATE TABLE public.shared_receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  run_id uuid NOT NULL,
  summary jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.shared_receipts TO authenticated;
GRANT ALL ON public.shared_receipts TO service_role;
ALTER TABLE public.shared_receipts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own shared receipts select" ON public.shared_receipts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own shared receipts insert" ON public.shared_receipts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own shared receipts delete" ON public.shared_receipts FOR DELETE TO authenticated USING (auth.uid() = user_id);
-- Public read by exact link id only (no listing).
CREATE OR REPLACE FUNCTION public.get_shared_receipt(_id uuid)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT summary || jsonb_build_object('shared_at', created_at) FROM public.shared_receipts WHERE id = _id
$$;
REVOKE ALL ON FUNCTION public.get_shared_receipt(uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.get_shared_receipt(uuid) TO anon, authenticated;