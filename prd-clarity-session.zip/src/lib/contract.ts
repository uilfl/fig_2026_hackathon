/** Pure contract helpers: versions, diffs, plain-language previews (no I/O). */
import { ACTION_LABEL, ASK_LABEL, asksFor, type ActionKey, type AskAt, type Contract, type Reversibility, type Rule } from "./engine";

export type Snapshot = Pick<Contract, "goal" | "budget_cap" | "headcount" | "triggers" | "rules">;
export type Version = { version: number; snapshot: Snapshot; diff: string[]; signed_at: string };

export const ACTIONS: { key: ActionKey; level: Reversibility; reach: number; reachLabel: string }[] = [
  { key: "plan", level: "free", reach: 0.15, reachLabel: "No money moves" },
  { key: "catering", level: "until_deadline", reach: 0.5, reachLabel: "$1,020 refundable" },
  { key: "deposit", level: "never", reach: 0.72, reachLabel: "$1,600 non-refundable" },
  { key: "invites", level: "never", reach: 0.92, reachLabel: "Emails 12 people" },
];
/** Thresholds offered on the risk map, loosest-asking last. */
export const THRESHOLDS: AskAt[] = ["free", "until_deadline", "never", "off"];
export const THRESHOLD_EXAMPLE: Record<AskAt, string> = {
  free: "e.g. even picking a venue",
  fee: "e.g. bookings with a cancellation fee",
  until_deadline: "e.g. refundable catering, deposits, sent emails",
  never: "e.g. deposits, sent emails",
  off: "e.g. nothing — agents never stop",
};

const rulesKey = (r: Rule[]) => JSON.stringify(r.map((x) => [x.key, x.kind ?? "keep", typeof x.value === "string" ? x.value : x.value ? (x.value as { recipients_hash?: string }).recipients_hash : null, x.label]));
const norm = (s: Snapshot) => JSON.stringify([s.goal.trim(), Number(s.budget_cap), Number(s.headcount), s.triggers.ask_at, !!s.triggers.over_budget, Object.entries(s.triggers.actions ?? {}).filter(([, v]) => v != null).sort(), rulesKey(s.rules)]);
export const sameContract = (a: Snapshot, b: Snapshot) => norm(a) === norm(b);

/** Human-readable changes from one version to the next, e.g. "+ Rule: venues must have parking". */
export function contractDiff(prev: Snapshot | null, next: Snapshot): string[] {
  if (!prev) return ["First signed version"];
  const out: string[] = [];
  if (prev.goal.trim() !== next.goal.trim()) out.push(`Goal: ${prev.goal} → ${next.goal}`);
  if (Number(prev.headcount) !== Number(next.headcount)) out.push(`Headcount: ${prev.headcount} → ${next.headcount}`);
  if (Number(prev.budget_cap) !== Number(next.budget_cap)) out.push(`Budget cap: $${Number(prev.budget_cap).toLocaleString()} → $${Number(next.budget_cap).toLocaleString()}`);
  if (!!prev.triggers.over_budget !== !!next.triggers.over_budget) out.push(`Over budget: ${next.triggers.over_budget ? "fine → check with me" : "check with me → fine"}`);
  if (prev.triggers.ask_at !== next.triggers.ask_at) out.push(`Threshold: ${ASK_LABEL[prev.triggers.ask_at].toLowerCase()} → ${ASK_LABEL[next.triggers.ask_at].toLowerCase()}`);
  for (const k of Object.keys(ACTION_LABEL) as ActionKey[]) {
    const a = prev.triggers.actions?.[k], b = next.triggers.actions?.[k];
    if (a !== b) out.push(b == null ? `Override removed: ${ACTION_LABEL[k]}` : `Override: ${ACTION_LABEL[k]} → ${b ? "asks you" : "goes ahead"}`);
  }
  for (const r of next.rules) if (!prev.rules.some((p) => p.key === r.key)) out.push(`+ Rule: ${r.label}`);
  for (const r of prev.rules) if (!next.rules.some((p) => p.key === r.key)) out.push(`− Rule: ${r.label}`);
  return out;
}

/** Button label: the version number only increments when something changed. */
export function signLabel(latest: Version | null, draft: Snapshot): { label: string; next: number; changed: boolean } {
  if (!latest) return { label: "Sign v1 & run agents", next: 1, changed: true };
  const changed = !sameContract(latest.snapshot, draft);
  return changed ? { label: `Sign v${latest.version + 1} & run agents`, next: latest.version + 1, changed } : { label: `Run again under v${latest.version}`, next: latest.version, changed };
}

/** Which actions ask, and a sentence saying what the agents will do. */
export function planPreview(t: Contract["triggers"]) {
  const rows = ACTIONS.map((a) => ({ ...a, asks: asksFor(a.key, a.level, t), overridden: t.actions?.[a.key] != null }));
  const asking = rows.filter((r) => r.asks);
  const phrase: Record<ActionKey, [string, string]> = {
    plan: ["pick the budget split, venue and dates", "before picking the venue and dates"],
    catering: ["book the caterer", "before booking the caterer"],
    deposit: ["pay the $1,600 deposit", "for the $1,600 deposit"],
    invites: ["email 12 people", "before emailing 12 people"],
  };
  const join = (xs: string[]) => xs.length <= 1 ? xs.join("") : `${xs.slice(0, -1).join(", ")} and ${xs.at(-1)}`;
  const own = rows.filter((r) => !r.asks).map((r) => phrase[r.key][0]);
  const stop = asking.map((r) => phrase[r.key][1]);
  const a = own.length ? `Agents will ${join(own)} on their own.` : "Agents won't do anything on their own.";
  const b = stop.length ? ` They'll stop ${join(stop)}.` : " They won't stop to ask you.";
  return { rows, asking: asking.length, header: `With this contract, ${asking.length} of ${rows.length} actions will ask you.`, summary: a + b };
}

/** Index in THRESHOLDS for a threshold (fee is treated as until_deadline's neighbour). */
export const thresholdIndex = (a: AskAt) => { const i = THRESHOLDS.indexOf(a); return i < 0 ? 1 : i; };
/** Column (0..4) where the "Asks you" zone starts: free=0 … off=4 (empty zone). */
export const zoneStart = (a: AskAt) => ({ free: 0, fee: 1, until_deadline: 2, never: 3, off: 4 } as const)[a];
export const COLUMN: Record<Reversibility, number> = { free: 0, fee: 1, until_deadline: 2, never: 3 };
/** Snap a dragged zone edge (in columns, 0..4) to the nearest offered threshold. */
export function snapThreshold(col: number): AskAt {
  let best: AskAt = "never", d = Infinity;
  for (const t of THRESHOLDS) { const dd = Math.abs(zoneStart(t) - col); if (dd < d) { d = dd; best = t; } }
  return best;
}

/** Only rules belong in House rules; one-time picks are not listed. */
export const isHouseRule = (r: Rule) => r.kind !== "override";
