import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { runScenario, normaliseTriggers, planReplacements, withRunRules, type Contract, type Attributed, type OldStep } from "./engine";

async function rationales(contract: Contract, steps: Attributed[]): Promise<string[]> {
  const fallback = steps.map((s) => (s.kind === "contract" ? "Your instructions for this delegation." : `${s.agent} proposed: ${s.action}.`));
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) return fallback;
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You are the planning voice of AI agents organizing a team offsite. For each step, write one short first-person sentence (max 22 words) explaining the agent's reasoning, mentioning the concrete criterion used. For payments and sends, speak as proposing (\"I propose…\"), never as if already done. Reply with JSON: {\"rationales\": string[]} in the same order." },
          { role: "user", content: JSON.stringify({ goal: contract.goal, budget: contract.budget_cap, headcount: contract.headcount, steps: steps.map((s) => ({ agent: s.agent, action: s.action, criterion: s.criterion_label, filtered_out: s.filtered_out, criteria: (s.criteria ?? [{ key: s.criterion, label: s.criterion_label }]).map((c) => c.label), effect: s.effect })) }) },
        ],
        response_format: { type: "json_object" },
      }),
    });
    if (!res.ok) return fallback;
    const data = await res.json();
    const parsed = JSON.parse(data.choices[0].message.content);
    const arr: unknown = parsed.rationales;
    if (!Array.isArray(arr) || arr.length !== steps.length) return fallback;
    return arr.map((r, i) => (typeof r === "string" && r ? r : fallback[i] ?? ""));
  } catch {
    return fallback;
  }
}

export const startRun = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase.from("contracts").select("*").eq("user_id", userId).maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Set up your contract first.");
    const contract = { ...(row as unknown as Contract), budget_cap: Number(row.budget_cap), triggers: normaliseTriggers(row.triggers) };
    const steps = runScenario(contract);
    const why = await rationales(contract, steps);
    // Older runs' approvals expire: only the newest run can be approved.
    const { error: expErr } = await supabase.from("ledger_entries").update({ status: "expired" }).eq("user_id", userId).in("status", ["pending", "blocked"]);
    if (expErr) throw new Error(expErr.message);
    const run_id = crypto.randomUUID();
    const rows = steps.map((s, i) => ({
      user_id: userId, run_id, seq: i, agent: s.agent, kind: s.kind, action: s.action, rationale: why[i] ?? "",
      source: s.source, status: s.status, criterion: s.criterion, depends_on: s.depends_on ?? null, inputs: (s.inputs ?? []) as never, default_key: s.default_key, default_label: s.default_label,
      options_considered: s.options_considered, filtered_out: s.filtered_out, preview: s.preview as never, criteria: s.criteria_out as never,
    }));
    const { error: insErr } = await supabase.from("ledger_entries").insert(rows);
    if (insErr) throw new Error(insErr.message);
    return { run_id };
  });

/** Re-plan within a run after a default is resolved: supersede changed/downstream steps and write fresh ones. */
export const replanRun = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ run_id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase.from("contracts").select("*").eq("user_id", userId).maybeSingle();
    if (error || !row) throw new Error(error?.message ?? "No contract");
    const { data: everyRow, error: e2 } = await supabase.from("ledger_entries").select("*").eq("run_id", data.run_id);
    if (e2) throw new Error(e2.message);
    // "Just this run" choices live on the run's rows and win over contract rules.
    const contract = withRunRules({ ...(row as unknown as Contract), budget_cap: Number(row.budget_cap), triggers: normaliseTriggers(row.triggers) }, everyRow ?? []);
    const olds = (everyRow ?? []).filter((o) => o.status !== "superseded");
    const none = { replaced: 0, inserted: [] as string[], superseded: [] as string[] };
    if (!olds.length || olds.some((o) => o.status === "expired")) return none;
    const fresh = runScenario(contract);
    const seqs = planReplacements(olds as unknown as OldStep[], fresh);
    if (!seqs.length) return none;
    const targets = olds.filter((o) => seqs.includes(o.seq));
    const { error: e3 } = await supabase.from("ledger_entries").update({ status: "superseded" }).in("id", targets.map((t) => t.id));
    if (e3) throw new Error(e3.message);
    const steps = fresh.filter((f) => seqs.includes(f.seq));
    const why = await rationales(contract, steps);
    const rows = steps.map((s, i) => {
      const prev = targets.find((t) => t.seq === s.seq);
      const carry = prev?.resolution && prev.default_key && prev.default_key === s.default_key ? prev.resolution : null;
      return {
        user_id: userId, run_id: data.run_id, seq: s.seq, agent: s.agent, kind: s.kind, action: s.action, rationale: why[i] ?? "",
        source: s.source, status: s.status, criterion: s.criterion, depends_on: s.depends_on ?? null, inputs: (s.inputs ?? []) as never,
        default_key: s.default_key, default_label: s.default_label, resolution: carry,
        options_considered: s.options_considered, filtered_out: s.filtered_out, preview: s.preview as never, criteria: s.criteria_out as never,
      };
    });
    const { data: ins, error: e4 } = await supabase.from("ledger_entries").insert(rows).select("id");
    if (e4) throw new Error(e4.message);
    return { replaced: rows.length, inserted: (ins ?? []).map((x) => x.id), superseded: targets.map((t) => t.id) };
  });
