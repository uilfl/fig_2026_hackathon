// Pure Cosign engine: simulated offsite scenario + system-side attribution.
// The agent reports a structured criterion; the system decides whose decision it was.
export type Reversibility = "free" | "fee" | "until_deadline" | "never";
export const REV_ORDER: Reversibility[] = ["free", "fee", "until_deadline", "never"];
/** Ask threshold: pause any side effect at least this hard to undo. "off" = never ask. */
export type AskAt = Reversibility | "off";
export type ActionKey = "plan" | "catering" | "deposit" | "invites";
/** Per-action overrides of the threshold: true = always ask, false = never ask. */
export type Triggers = { ask_at: AskAt; over_budget: boolean; actions?: Partial<Record<ActionKey, boolean>> };
export const ACTION_LABEL: Record<ActionKey, string> = { plan: "Pick budget split, venue, dates", catering: "Reserve catering", deposit: "Pay venue deposit", invites: "Send invites" };

export function actionKeyOf(step: { kind: string; effect?: Effect | undefined }): ActionKey {
  if (step.kind === "send") return "invites";
  if (step.kind === "spend") return step.effect?.type === "spend" && !step.effect.refundable ? "deposit" : "catering";
  return "plan";
}

/** Does this action ask? Per-action override wins; otherwise the reversibility threshold. */
export function asksFor(key: ActionKey, level: Reversibility, t: Triggers): boolean {
  const o = t.actions?.[key];
  return o ?? needsAsk(level, t.ask_at);
}

function askReason(key: ActionKey, level: Reversibility, t: Triggers): string {
  if (t.actions?.[key] === true) return `Your setting: “${ACTION_LABEL[key]}” — always ask`;
  return `${REV_LABEL[level]} — your setting: “${ASK_LABEL[t.ask_at]}”`;
}
/** keep = the agent's criterion becomes a contract rule; override = the user picked a specific option. */
/** scope = a saved approval: the action runs without asking while its recipients and message hash the same. */
export type ScopeValue = { recipients_hash: string; template_hash: string; recipients?: string; template?: string };
export type Rule = { key: string; label: string; kind?: "keep" | "override" | "scope"; value?: string | ScopeValue };
export const SCOPE_KEY = (k: ActionKey) => `scope:${k}`;
export function hashOf(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(16);
}
export function scopeOf(effect: Extract<Effect, { type: "send" }>): Required<ScopeValue> {
  const recipients = `${effect.recipients} people`;
  return { recipients, template: effect.subject, recipients_hash: hashOf(recipients), template_hash: hashOf(effect.subject) };
}
/** Compare a send against a saved scope. Returns null if it matches, else what changed. */
export function scopeDiff(saved: ScopeValue, now: Required<ScopeValue>): string[] | null {
  const d: string[] = [];
  if (saved.recipients_hash !== now.recipients_hash) d.push(`recipients: ${saved.recipients ?? "saved list"} → ${now.recipients}`);
  if (saved.template_hash !== now.template_hash) d.push(`message: “${saved.template ?? "saved message"}” → “${now.template}”`);
  return d.length ? d : null;
}
export type Contract = { goal: string; budget_cap: number; headcount: number; triggers: Triggers; rules: Rule[] };
export type Source = "user" | "approved" | "contract" | "default" | "pending";
export type Status = "done" | "pending" | "blocked";
export type Kind = "contract" | "select" | "spend" | "send";

export type Effect =
  | { type: "spend"; amount: number; refundable: false; payee: string; memo: string }
  | { type: "spend"; amount: number; refundable: true; payee: string; memo: string; cancel_by: string }
  | { type: "send"; channel: "email"; recipients: number; subject: string };

export type Preview = { what: string; reversibility: Reversibility; reversibility_note: string; amount?: number | undefined; total_after?: number | undefined; blocked_by?: string[] | undefined; scope?: Required<ScopeValue> | undefined; saved_scope?: boolean | undefined };

export type Step = {
  agent: string;
  kind: Kind;
  action: string;
  criterion: string; // structured key logged by the agent
  criterion_label: string;
  options_considered: string[];
  filtered_out: { option: string; reason: string }[];
  effect?: Effect;
  depends_on?: number; // seq of a step that must complete first
  inputs?: number[]; // seqs whose outputs this step uses (data dependencies)
  /** All criteria the agent logged; defaults to the single `criterion`. */
  criteria?: CriterionRef[];
  /** Agent-reported filtered_out may tag which criterion removed each option. */
  filtered_out_by?: { option: string; criterion: string }[];
  /** System-side re-check of a criterion against an option: true pass, false fail, undefined = judgement call. */
  check?: (key: string, option: string) => boolean | undefined;
  /** Options exempt from re-check (e.g. a user-forced pick). */
  exempt?: string[];
};

export type CriterionRef = { key: string; label: string };
export type CriterionSource = "you" | "contract" | "rule" | "default";
export type Criterion = CriterionRef & { source: CriterionSource; verified: boolean };

export type Attributed = Step & { seq: number; source: Source; criteria_out: Criterion[]; status: Status; default_key: string | null; default_label: string | null; preview: Preview | null };

/** Criteria grounded in the contract's own fields. */
const CONTRACT_CRITERIA = new Set(["user_contract", "headcount", "budget_cap", "ask_threshold"]);

export const ASK_LABEL: Record<AskAt, string> = {
  never: "Ask before anything that can't be undone",
  until_deadline: "Ask before anything with a refund deadline or worse",
  fee: "Ask before anything that costs a fee to undo",
  free: "Ask before every side effect",
  off: "Never ask",
};
export const REV_LABEL: Record<Reversibility, string> = { free: "Free to undo", fee: "Undo with a fee", until_deadline: "Undo until deadline", never: "Cannot be undone" };

export function needsAsk(level: Reversibility, askAt: AskAt): boolean {
  return askAt !== "off" && REV_ORDER.indexOf(level) >= REV_ORDER.indexOf(askAt);
}

/** The system — never the agent — assigns reversibility from the concrete effect. */
export function reversibilityOf(effect: Effect | undefined): { level: Reversibility; note: string } {
  if (!effect) return { level: "free", note: "Nothing leaves Cosign; can be changed any time." };
  if (effect.type === "spend") {
    if (!effect.refundable) return { level: "never", note: "Non-refundable. Money cannot be recovered." };
    return { level: "until_deadline", note: `Fully refundable until ${effect.cancel_by}.` };
  }
  return { level: "never", note: "Sent emails cannot be unsent." };
}

export function ruleFor(contract: Contract, key: string) {
  return contract.rules.find((r) => r.key === key);
}

/** Pick an option for a judgement call: user override > agent's pick. */
function choose<T>(contract: Contract, key: string, options: T[], name: (t: T) => string, agentPick: T): { pick: T; overridden: boolean } {
  const r = ruleFor(contract, key);
  if (r?.kind === "override" && typeof r.value === "string") {
    const o = options.find((x) => name(x) === r.value);
    if (o) return { pick: o, overridden: true };
  }
  return { pick: agentPick, overridden: false };
}

/** Strongest → weakest. A step's source is its weakest criterion. */
export const SOURCE_RANK: Source[] = ["user", "approved", "contract", "default"];
const CRIT_TO_SOURCE: Record<CriterionSource, Source> = { you: "user", contract: "contract", rule: "contract", default: "default" };
export function sourceFromCriteria(cs: Criterion[]): Source {
  let worst = 0;
  for (const c of cs) worst = Math.max(worst, SOURCE_RANK.indexOf(CRIT_TO_SOURCE[c.source]));
  return SOURCE_RANK[worst]!;
}

/**
 * Re-apply logged criteria to the options (in order; first failing criterion removes an option)
 * and compare with what the agent reported. Returns the keys of criteria whose claims don't hold.
 */
export function verifyCriteria(refs: CriterionRef[], options: string[], reported: { option: string; criterion: string }[], check: (key: string, option: string) => boolean | undefined, exempt: string[] = []): Set<string> {
  const bad = new Set<string>();
  const claimed = new Map(reported.map((r) => [r.option, r.criterion]));
  for (const o of options) {
    if (exempt.includes(o)) continue;
    const actual = refs.find((r) => check(r.key, o) === false)?.key;
    const claim = claimed.get(o);
    if (claim === actual) continue;
    if (claim) bad.add(claim);
    else if (actual) bad.add(actual);
  }
  return bad;
}

/** The system — never the agent — assigns each criterion's source. */
export function buildCriteria(refs: CriterionRef[], contract: Contract, overriddenKeys: string[] = [], unverified: Set<string> = new Set()): Criterion[] {
  return refs.map((r) => {
    if (unverified.has(r.key)) return { ...r, source: "default", verified: false };
    const rule = ruleFor(contract, r.key);
    const source: CriterionSource = overriddenKeys.includes(r.key) || rule?.kind === "override" ? "you" : CONTRACT_CRITERIA.has(r.key) ? "contract" : rule ? "rule" : "default";
    return { ...r, source, verified: true };
  });
}

export function attribute(step: Step, seq: number, contract: Contract, spentSoFar: number, overridden = false): Attributed {
  const refs = step.criteria ?? [{ key: step.criterion, label: step.criterion_label }];
  const unverified = step.kind === "select" && step.check && step.filtered_out_by ? verifyCriteria(refs, step.options_considered, step.filtered_out_by, step.check, step.exempt) : new Set<string>();
  const criteria_out = buildCriteria(refs, contract, overridden ? [step.criterion] : [], unverified);
  const firstDefault = criteria_out.find((c) => c.source === "default" && (c.key === step.criterion || !c.verified)) ?? null;
  const base = { ...step, seq, criteria_out, default_key: null as string | null, default_label: null as string | null, preview: null as Preview | null };
  if (step.kind === "contract") return { ...base, source: "user", status: "done" };

  if (step.kind === "select") {
    if (asksFor("plan", "free", contract.triggers)) {
      const preview: Preview = { what: step.action, reversibility: "free", reversibility_note: "Nothing leaves Cosign; can be changed any time.", blocked_by: [askReason("plan", "free", contract.triggers)] };
      return { ...base, preview, source: "pending", status: "pending" };
    }
    const source = sourceFromCriteria(criteria_out);
    // Only the step's own default is resolvable here; inherited defaults are resolved on their own step.
    return { ...base, source, status: "done", default_key: firstDefault?.key ?? null, default_label: firstDefault?.label ?? null };
  }

  const effect = step.effect!;
  const rev = reversibilityOf(effect);
  const blocked: string[] = [];
  let amount: number | undefined;
  let total: number | undefined;
  let what = "";
  if (effect.type === "spend") {
    amount = effect.amount;
    total = spentSoFar + effect.amount;
    what = `Pay $${effect.amount.toLocaleString()} to ${effect.payee} — ${effect.memo}`;
    if (contract.triggers.over_budget && total > contract.budget_cap) blocked.push(`Would exceed budget cap of $${contract.budget_cap.toLocaleString()} (your setting: ask before going over budget)`);
  }
  const key = actionKeyOf(step);
  let scope: Required<ScopeValue> | undefined;
  let savedScope = false;
  if (effect.type === "send") {
    what = `Email ${effect.recipients} people: “${effect.subject}”`;
    scope = scopeOf(effect);
  }
  if (asksFor(key, rev.level, contract.triggers)) {
    const saved = scope ? contract.rules.find((r) => r.key === SCOPE_KEY(key) && r.kind === "scope") : undefined;
    const diff = saved && typeof saved.value === "object" ? scopeDiff(saved.value, scope!) : undefined;
    if (saved && diff === null) savedScope = true;
    else blocked.unshift(diff ? `Saved scope doesn't match — ${diff.join("; ")}` : askReason(key, rev.level, contract.triggers));
  }
  const preview: Preview = { what, reversibility: rev.level, reversibility_note: rev.note, amount, total_after: total, blocked_by: blocked.length ? blocked : undefined, scope, saved_scope: savedScope || undefined };
  return blocked.length ? { ...base, preview, source: "pending", status: "pending" } : { ...base, preview, source: savedScope ? "approved" : "contract", status: "done" };
}

export const VENUES = [
  { name: "Lakeside Lodge", cap: 20, price: 3200, parking: true },
  { name: "The Foundry Loft", cap: 16, price: 2600, parking: false },
  { name: "Cedar Hall", cap: 10, price: 1900, parking: true },
  { name: "Harbor House", cap: 14, price: 2400, parking: false },
  { name: "Ridgeview Inn", cap: 24, price: 5200, parking: true },
];
const SHARES = ["50%", "60%", "70%"];
const DATES = ["Mar 14–15", "Mar 21–22", "Apr 4–5"];

export const CONFLICT_KEY = "venue_conflict";
export const VENUE_AGENT_PICK = "Ridgeview Inn";
export const SHARE_OPTIONS = SHARES;

/** Run-scoped choices ("just this run") recorded as `override:<value>` on a step row, keyed by its criterion. They win over contract rules. */
export function withRunRules<C extends Contract>(contract: C, rows: { criterion: string | null; resolution: string | null; created_at?: string }[]): C {
  const picks = new Map<string, string>();
  for (const r of [...rows].sort((a, b) => (a.created_at ?? "").localeCompare(b.created_at ?? ""))) if (r.criterion && r.resolution?.startsWith("override:")) picks.set(r.criterion, r.resolution.slice(9));
  if (!picks.size) return contract;
  const extra: Rule[] = [...picks].map(([key, value]) => ({ key, label: `This run: ${value}`, kind: "override", value }));
  return { ...contract, rules: [...contract.rules.filter((r) => !picks.has(r.key)), ...extra] };
}

export function venueCheck(contract: Contract, venueBudget: number, parkingOff = false) {
  return (key: string, name: string): boolean | undefined => {
    const v = VENUES.find((x) => x.name === name);
    if (!v) return undefined;
    if (key === "headcount") return v.cap >= contract.headcount;
    if (key === "venue_share_60") return v.price <= venueBudget;
    if (key === "budget_cap") return v.price <= contract.budget_cap;
    if (key === "require_parking") return parkingOff ? undefined : v.parking;
    return undefined;
  };
}

export function runScenario(contract: Contract): Attributed[] {
  const out: Attributed[] = [];
  let spent = 0;
  const push = (s: Step, overridden = false) => {
    const a = attribute(s, out.length, contract, spent, overridden);
    if (a.effect?.type === "spend") spent += a.effect.amount;
    // A step that waits on a paused/blocked step is blocked, whatever its own status.
    if (s.depends_on != null && out[s.depends_on] && out[s.depends_on]!.status !== "done") a.status = "blocked";
    out.push(a);
    return a;
  };

  push({ agent: "You", kind: "contract", action: `Set goal “${contract.goal}”, ${contract.headcount} people, $${contract.budget_cap.toLocaleString()} cap`, criterion: "user_contract", criterion_label: "Your delegation contract", options_considered: [], filtered_out: [] });

  const shareSeq = out.length;
  const share = choose(contract, "venue_share_60", SHARES, (x) => x, "60%");
  const venueBudget = Math.round((contract.budget_cap * Number(share.pick.replace("%", ""))) / 100);
  push({ agent: "Budget agent", kind: "select", action: `Allocated ${share.pick} of budget ($${venueBudget.toLocaleString()}) to the venue`, criterion: "venue_share_60", criterion_label: "Spend 60% of the budget on the venue", options_considered: SHARES, filtered_out: SHARES.filter((x) => x !== share.pick).map((x) => ({ option: x, reason: share.overridden ? "You chose otherwise" : "Agent's usual split is 60%" })) }, share.overridden);

  const filtered: { option: string; reason: string; criterion: string }[] = [];
  const parkingKeep = ruleFor(contract, "require_parking");
  const ok: typeof VENUES = [];
  for (const v of VENUES) {
    if (v.cap < contract.headcount) filtered.push({ option: v.name, reason: `Fits ${v.cap}, need ${contract.headcount}`, criterion: "headcount" });
    else if (v.price > venueBudget) filtered.push({ option: v.name, reason: `$${v.price.toLocaleString()} over venue share $${venueBudget.toLocaleString()}`, criterion: "venue_share_60" });
    else if (!v.parking && parkingKeep?.kind !== "override") filtered.push({ option: v.name, reason: "No on-site parking", criterion: "require_parking" });
    else ok.push(v);
  }

  // Agent conflict: the Venue agent prefers the best venue for the group; the Budget agent rejects it when it's over the venue share.
  const pref = VENUES.find((v) => v.name === VENUE_AGENT_PICK)!;
  const venueOverride = choose(contract, "require_parking", VENUES, (v) => v.name, ok[0] ?? VENUES[0]!);
  const conflict = pref.cap >= contract.headcount && pref.parking && pref.price > venueBudget;
  let settled: (typeof VENUES)[number] | null = null;
  let sideBudget = false;
  if (conflict) {
    const r = ruleFor(contract, CONFLICT_KEY);
    const rv = typeof r?.value === "string" ? r.value : null;
    sideBudget = rv === "budget";
    if (rv === "venue") settled = pref;
    else if (rv === "budget") settled = ok[0] ?? VENUES[0]!;
    else if (rv && VENUES.some((v) => v.name === rv)) settled = VENUES.find((v) => v.name === rv)!;
    else if (venueOverride.overridden) settled = venueOverride.pick;
    else if (share.overridden && Number(share.pick.replace("%", "")) > 60) settled = pref; // raising the split sides with the Venue agent
  }
  let conflictSeq: number | undefined;
  if (conflict) {
    conflictSeq = out.length;
    const over = pref.price - venueBudget;
    const a = push({ agent: "Cosign", kind: "select", criterion: CONFLICT_KEY, criterion_label: "Agents disagree on the venue",
      action: settled ? `You settled a disagreement between Venue and Budget agents → ${settled.name}` : `Agents disagree: Venue agent wants ${pref.name} (fits ${pref.cap}, parking); Budget agent says over venue share by $${over.toLocaleString()}`,
      options_considered: ["venue", "budget"], filtered_out: [], inputs: [shareSeq] }, !!settled);
    if (!settled) {
      a.status = "pending"; a.source = "pending";
      a.preview = { what: `Venue agent wants ${pref.name} — fits ${pref.cap}, parking. Budget agent says: over venue share by $${over.toLocaleString()}.`, reversibility: "free", reversibility_note: "Nothing is booked yet.", blocked_by: ["Agents disagree — Cosign never picks a side for you"] };
    }
  }
  const shortlistSeq = out.length;
  const venue = settled ? { pick: settled, overridden: !sideBudget } : venueOverride;
  push({ agent: "Venue agent", kind: "select", action: `Shortlisted ${venue.pick.name}`, criterion: "require_parking", criterion_label: "Venues must have on-site parking", options_considered: VENUES.map((v) => v.name), filtered_out: filtered.filter((f) => f.option !== venue.pick.name).map(({ option, reason }) => ({ option, reason })),
    criteria: [
      { key: "headcount", label: `Fits all ${contract.headcount} people` },
      { key: "venue_share_60", label: `Within the ${share.pick} venue share ($${venueBudget.toLocaleString()})` },
      { key: "require_parking", label: "Venues must have on-site parking" },
    ],
    filtered_out_by: filtered.filter((f) => f.option !== venue.pick.name).map((f) => ({ option: f.option, criterion: f.criterion })),
    check: venueCheck(contract, venueBudget, parkingKeep?.kind === "override"),
    exempt: venue.overridden ? [venue.pick.name] : [],
    inputs: conflictSeq != null ? [shareSeq, conflictSeq] : [shareSeq],
    ...(conflictSeq != null ? { depends_on: conflictSeq } : {}),
  }, venue.overridden);

  const datesSeq = out.length;
  const date = choose(contract, "earliest_weekend", DATES, (x) => x, DATES[0]!);
  push({ agent: "Venue agent", kind: "select", action: `Picked dates ${date.pick}`, criterion: "earliest_weekend", criterion_label: "Book the earliest open weekend", options_considered: DATES, filtered_out: DATES.filter((d) => d !== date.pick).map((d) => ({ option: d, reason: date.overridden ? "You chose otherwise" : "Later than earliest" })), inputs: [shortlistSeq], depends_on: shortlistSeq }, date.overridden);

  const deposit = Math.round(venue.pick.price * 0.5);
  const depositSeq = out.length;
  push({ agent: "Budget agent", kind: "spend", action: `Pay venue deposit to ${venue.pick.name}`, criterion: "budget_cap", criterion_label: "Within your budget cap", options_considered: [venue.pick.name], filtered_out: [], inputs: [shareSeq, shortlistSeq, datesSeq], depends_on: datesSeq, effect: { type: "spend", amount: deposit, refundable: false, payee: venue.pick.name, memo: `50% deposit for ${date.pick}, non-refundable` } });

  const catering = contract.headcount * 85;
  push({ agent: "Budget agent", kind: "spend", action: "Reserve catering with Green Fork", criterion: "budget_cap", criterion_label: "Within your budget cap", options_considered: ["Green Fork ($85/person)", "Basil & Co ($110/person)"], filtered_out: [{ option: "Basil & Co ($110/person)", reason: "Pricier for the same menu" }], inputs: [datesSeq], depends_on: datesSeq, effect: { type: "spend", amount: catering, refundable: true, payee: "Green Fork Catering", memo: `${contract.headcount} × $85 lunch`, cancel_by: "Mar 7" } });

  push({ agent: "Invites agent", kind: "send", action: "Send calendar invites", criterion: "headcount", criterion_label: `Invite all ${contract.headcount} people in your headcount`, options_considered: [`All ${contract.headcount} people`], filtered_out: [], depends_on: depositSeq, inputs: [datesSeq, depositSeq], effect: { type: "send", channel: "email", recipients: contract.headcount, subject: `Team offsite at ${venue.pick.name}, ${date.pick}` } });
  return out;
}

/** Status of a step that was blocked, once the step it depends on is decided. */
export function unblockedStatus(ownBlockedBy: string[] | undefined, approved: boolean, savedScope = false): { status: string; source: Source } {
  if (!approved) return { status: "cancelled", source: "user" };
  return ownBlockedBy?.length ? { status: "pending", source: "pending" } : { status: "done", source: savedScope ? "approved" : "contract" };
}

/** Normalise contracts saved before the reversibility threshold existed. */
export function normaliseTriggers(t: unknown): Triggers {
  const o = (t ?? {}) as Record<string, unknown>;
  if (typeof o["ask_at"] === "string") return { ask_at: o["ask_at"] as AskAt, over_budget: o["over_budget"] !== false, actions: (o["actions"] as Triggers["actions"]) ?? {} };
  return { ask_at: o["non_refundable_spend"] || o["irreversible_send"] ? "never" : "off", over_budget: o["over_budget"] !== false };
}

// ---------- Data dependencies & re-planning ----------

export type DepNode = { seq: number; inputs?: unknown; depends_on?: number | null };

/** Every step upstream of `seq` (transitive via inputs and depends_on). */
export function upstreamOf(seq: number, steps: DepNode[]): number[] {
  const bySeq = new Map(steps.map((s) => [s.seq, s]));
  const seen = new Set<number>();
  const visit = (q: number) => {
    const n = bySeq.get(q);
    if (!n) return;
    const ups = [...((Array.isArray(n.inputs) ? n.inputs : []) as number[]), ...(n.depends_on != null ? [n.depends_on] : [])];
    for (const u of ups) if (!seen.has(u)) { seen.add(u); visit(u); }
  };
  visit(seq);
  return [...seen].sort((a, b) => a - b);
}

export type OldStep = DepNode & { action: string; preview: unknown; source: string; status: string };

/** Seqs to supersede: steps whose recomputed output differs, plus everything downstream of them. Decided steps stay. */
export function planReplacements(old: OldStep[], fresh: Attributed[]): number[] {
  // Compare outcomes (action + preview), with sorted keys since stored JSON may reorder them.
  const canon = (v: unknown): unknown => Array.isArray(v) ? v.map(canon) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).filter(([, x]) => x !== undefined).sort(([a], [b]) => a.localeCompare(b)).map(([k, x]) => [k, canon(x)])) : v;
  const sig = (x: { action: string; preview: unknown }) => JSON.stringify(canon([x.action, x.preview ?? null]));
  const changed = new Set<number>();
  for (const f of fresh) {
    const o = old.find((x) => x.seq === f.seq);
    if (!o || sig(o) !== sig({ action: f.action, preview: f.preview })) changed.add(f.seq);
  }
  const out = new Set(changed);
  for (const f of fresh) if (upstreamOf(f.seq, fresh).some((u) => changed.has(u))) out.add(f.seq);
  const locked = (o: OldStep | undefined) => !!o && ((o.source === "approved" && o.status === "done") || o.status === "declined" || o.status === "expired");
  return [...out].filter((q) => q !== 0 && !locked(old.find((x) => x.seq === q))).sort((a, b) => a - b);
}

/** Irreversible spends/sends go on the single commit card instead of separate decision cards. */
export function isCommitStep(e: { kind: string; status: string; preview: unknown }): boolean {
  const p = e.preview as Preview | null;
  return (e.kind === "spend" || e.kind === "send") && p?.reversibility === "never" && (e.status === "pending" || e.status === "blocked");
}

/** Approvals = distinct user decisions (a commit approves several steps at once); saved-scope runs aren't approvals. */
export function countApprovals(rows: { source: string; status: string; decided_at: string | null; preview: unknown }[]): number {
  return new Set(rows.filter((r) => r.source === "approved" && r.status !== "superseded" && !(r.preview as Preview | null)?.saved_scope).map((r) => r.decided_at)).size;
}

/** Suggest a saved scope when an action was approved in the last 2 runs with no "should have asked" flags. Never suggests "Goes ahead". */
export function scopeSuggestion(runs: { kind: string; source: string; resolution: string | null; preview: unknown }[][], contract: Contract): ActionKey | null {
  const last = runs.slice(0, 2);
  if (last.length < 2 || contract.rules.some((r) => r.key === SCOPE_KEY("invites"))) return null;
  const ok = last.every((run) => !run.some((e) => e.resolution === "should_have_asked") && run.some((e) => e.kind === "send" && e.source === "approved" && !(e.preview as Preview | null)?.saved_scope));
  return ok ? "invites" : null;
}

// ---------- Alternatives after a decline ----------

/** Judgement calls a declined step can be re-planned around (others stay as they are). */
const ALT_KEYS = ["require_parking", "earliest_weekend"] as const;
export type Alternative = { key: string; value: string; kind: "venue" | "dates"; preview: string; passes: boolean; note?: string | undefined };
type AltStep = DepNode & { kind: string; criterion: string | null; action: string; status: string; options_considered?: unknown };

/** Other options the agent already considered, upstream of the declined step, each with a preview. */
export function alternativesFor(declinedSeq: number, run: AltStep[], contract: Contract): Alternative[] {
  const live = run.filter((s) => s.status !== "superseded");
  const ups = upstreamOf(declinedSeq, live);
  const share = choose(contract, "venue_share_60", SHARES, (x) => x, "60%").pick;
  const venueBudget = Math.round((contract.budget_cap * Number(share.replace("%", ""))) / 100);
  const parkingOff = ruleFor(contract, "require_parking")?.kind === "override";
  const venueStep = live.find((s) => ups.includes(s.seq) && s.criterion === "require_parking");
  const dateStep = live.find((s) => ups.includes(s.seq) && s.criterion === "earliest_weekend");
  const curVenue = VENUES.find((v) => venueStep?.action.includes(v.name)) ?? VENUES[0]!;
  const curDate = DATES.find((d) => dateStep?.action.includes(d));
  const out: Alternative[] = [];
  if (venueStep) for (const v of VENUES) {
    if (v.name === curVenue.name) continue;
    const why = v.cap < contract.headcount ? `Fits ${v.cap}, need ${contract.headcount}` : v.price > venueBudget ? `Over the ${share} venue share ($${venueBudget.toLocaleString()})` : !v.parking && !parkingOff ? "No on-site parking" : undefined;
    out.push({ key: ALT_KEYS[0], value: v.name, kind: "venue", passes: !why, note: why, preview: `Deposit $${Math.round(v.price * 0.5).toLocaleString()} to ${v.name} · fits ${v.cap} · ${v.parking ? "parking" : "no parking"}${curDate ? ` · ${curDate}` : ""}` });
  }
  if (dateStep) for (const d of DATES) {
    if (d === curDate) continue;
    out.push({ key: ALT_KEYS[1], value: d, kind: "dates", passes: true, preview: `Deposit $${Math.round(curVenue.price * 0.5).toLocaleString()} to ${curVenue.name} for ${d}` });
  }
  return out;
}

/** "Ask the agent for another option": next venue that passes every filter, else the next dates. */
export function nextAlternative(alts: Alternative[]): Alternative | undefined {
  return alts.find((a) => a.kind === "venue" && a.passes) ?? alts.find((a) => a.kind === "dates");
}
