import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { normaliseTriggers, type Contract, type Rule } from "./engine";

export type ContractRow = Contract & { user_id: string };

export const contractQuery = queryOptions({
  queryKey: ["contract"],
  queryFn: async (): Promise<ContractRow> => {
    const { data: u } = await supabase.auth.getUser();
    const uid = u.user!.id;
    let { data } = await supabase.from("contracts").select("*").eq("user_id", uid).maybeSingle();
    if (!data) {
      const ins = await supabase.from("contracts").insert({ user_id: uid }).select("*").single();
      if (ins.error) throw ins.error;
      data = ins.data;
    }
    return { ...data, budget_cap: Number(data.budget_cap), triggers: normaliseTriggers(data.triggers), rules: data.rules as unknown as Rule[] };
  },
});

export const ledgerQuery = queryOptions({
  queryKey: ["ledger"],
  queryFn: async () => {
    const { data, error } = await supabase.from("ledger_entries").select("*").order("created_at", { ascending: false }).order("seq").limit(300);
    if (error) throw error;
    return data;
  },
});

export const profileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async () => {
    const { data } = await supabase.from("profiles").select("*").maybeSingle();
    return data;
  },
});

export const versionsQuery = queryOptions({
  queryKey: ["contract_versions"],
  queryFn: async () => {
    const { data, error } = await supabase.from("contract_versions").select("*").order("version", { ascending: false });
    if (error) throw error;
    return data.map((v) => ({ ...v, snapshot: v.snapshot as unknown as import("./contract").Snapshot, diff: (v.diff as string[]) ?? [] }));
  },
});

/** Contract version a run ran under: the latest version signed at or before the run started. */
export function versionAt(versions: { version: number; signed_at: string }[], at: string): number | null {
  return versions.find((v) => v.signed_at <= at)?.version ?? null;
}
