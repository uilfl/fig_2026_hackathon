import { describe, expect, it } from "vitest";
import { contractDiff, planPreview, signLabel, snapThreshold, isHouseRule, type Snapshot } from "./contract";

const base: Snapshot = { goal: "a two-day team offsite", budget_cap: 6000, headcount: 12, triggers: { ask_at: "never", over_budget: true, actions: {} }, rules: [] };

describe("contract versions", () => {
  it("keeps the version when nothing changed", () => {
    expect(signLabel({ version: 3, snapshot: base, diff: [], signed_at: "" }, base).label).toBe("Run again under v3");
  });
  it("increments the version when something changed", () => {
    expect(signLabel({ version: 3, snapshot: base, diff: [], signed_at: "" }, { ...base, budget_cap: 7000 }).label).toBe("Sign v4 & run agents");
  });
  it("lists an added rule and a threshold change", () => {
    const d = contractDiff({ ...base, triggers: { ...base.triggers, ask_at: "off" } }, { ...base, rules: [{ key: "require_parking", label: "Venues must have parking", kind: "keep" }] });
    expect(d).toContain("+ Rule: Venues must have parking");
    expect(d).toContain("Threshold: never ask → ask before anything that can't be undone");
  });
});

describe("plan preview", () => {
  it("asks for 2 of 4 under can't-be-undone", () => {
    const p = planPreview(base.triggers);
    expect(p.header).toBe("With this contract, 2 of 4 actions will ask you.");
    expect(p.summary).toBe("Agents will pick the budget split, venue and dates and book the caterer on their own. They'll stop for the $1,600 deposit and before emailing 12 people.");
  });
  it("an override flips one action", () => {
    expect(planPreview({ ...base.triggers, actions: { invites: false } }).asking).toBe(1);
  });
  it("snaps the dragged edge to the nearest threshold", () => {
    expect(snapThreshold(2.8)).toBe("never");
    expect(snapThreshold(1.7)).toBe("until_deadline");
    expect(snapThreshold(3.9)).toBe("off");
  });
  it("one-time overrides are not house rules", () => {
    expect(isHouseRule({ key: "earliest_weekend", label: "x", kind: "override", value: "Mar 21–22" })).toBe(false);
    expect(isHouseRule({ key: "require_parking", label: "x", kind: "keep" })).toBe(true);
  });
});
