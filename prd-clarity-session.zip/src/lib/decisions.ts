import { supabase } from "@/integrations/supabase/client";
import type { ledgerQuery, ContractRow } from "./queries";
import { unblockedStatus, upstreamOf, SCOPE_KEY, CONFLICT_KEY, type Alternative, type Preview, type Rule } from "./engine";
import { replanRun } from "./cosign.functions";

export type Entry = Awaited<ReturnType<NonNullable<typeof ledgerQuery.queryFn>>>[number];

/** Approve/decline a paused step, then release or cancel steps that depended on it. */
export async function decide(e: Entry, approve: boolean, all: Entry[]) {
  const now = new Date().toISOString();
  const { error } = await supabase.from("ledger_entries").update(approve ? { source: "approved", status: "done", decided_at: now } : { source: "user", status: "declined", decided_at: now }).eq("id", e.id).eq("status", "pending");
  if (error) throw error;
  // A decline leaves dependents blocked until the user picks an alternative or stops the run.
  if (!approve) return;
  for (const d of all.filter((x) => x.run_id === e.run_id && x.depends_on === e.seq && x.status === "blocked")) {
    const dp = d.preview as Preview | null;
    const next = unblockedStatus(dp?.blocked_by, approve, !!dp?.saved_scope);
    const { error: e2 } = await supabase.from("ledger_entries").update(next).eq("id", d.id);
    if (e2) throw e2;
  }
}

export type Resolution = "keep" | "once" | "override";

/** Resolve a flagged default: keep as rule, accept just this time, or override with another option. */
export async function resolveDefault(e: Entry, contract: ContractRow, how: Resolution, value?: string) {
  if (how !== "once") {
    const rule: Rule = how === "keep" ? { key: e.default_key!, label: e.default_label!, kind: "keep" } : { key: e.default_key!, label: `Use ${value} instead of “${e.default_label}”`, kind: "override", value: value! };
    const rules = [...contract.rules.filter((r) => r.key !== rule.key), rule];
    const { error } = await supabase.from("contracts").update({ rules: rules as never }).eq("user_id", contract.user_id);
    if (error) throw error;
  }
  const { error } = await supabase.from("ledger_entries").update({ resolution: how === "override" ? `override:${value}` : how, decided_at: new Date().toISOString() }).eq("id", e.id);
  if (error) throw error;
  // Re-plan the same run so downstream steps reflect the decision.
  return replanRun({ data: { run_id: e.run_id } });
}

export const isOpenConflict = (e: Entry) => e.criterion === CONFLICT_KEY && e.status === "pending";

export const isOpenDefault = (e: Entry) => e.source === "default" && !!e.default_key && !e.resolution && e.status !== "superseded" && e.status !== "expired";

/** Unresolved defaults in steps upstream of `e` (its data dependencies), same run. */
export function unresolvedUpstream(e: Entry, all: Entry[]): Entry[] {
  const run = all.filter((x) => x.run_id === e.run_id && x.status !== "superseded");
  const ups = upstreamOf(e.seq, run.map((x) => ({ seq: x.seq, inputs: x.inputs, depends_on: x.depends_on })));
  return run.filter((x) => ups.includes(x.seq) && (isOpenDefault(x) || isOpenConflict(x)));
}

export async function flagShouldHaveAsked(e: Entry) {
  const { error } = await supabase.from("ledger_entries").update({ resolution: "should_have_asked" }).eq("id", e.id);
  if (error) throw error;
}

export function latestRun(entries: Entry[]): Entry[] {
  const id = entries[0]?.run_id;
  return entries.filter((e) => e.run_id === id).sort((a, b) => a.seq - b.seq || a.created_at.localeCompare(b.created_at));
}

/** One approval for every irreversible step in the run. Unchecked steps are declined; steps depending on a declined one are cancelled. */
export async function commitPlan(items: Entry[], include: Set<string>, all: Entry[], scope: { contract: ContractRow; invite: Entry } | null) {
  const now = new Date().toISOString();
  const declined = new Set<number>();
  const ids = new Set(items.map((i) => i.id));
  for (const e of [...items].sort((a, b) => a.seq - b.seq)) {
    const off = !include.has(e.id) || (e.depends_on != null && declined.has(e.depends_on));
    if (off) declined.add(e.seq);
    // A step left waiting on a declined one stays blocked: the decline panel decides what happens next.
    if (off && (include.has(e.id) || (e.depends_on != null && declined.has(e.depends_on)))) continue;
    const patch = off ? { source: "user", status: include.has(e.id) ? "cancelled" : "declined", decided_at: now } : { source: "approved", status: "done", decided_at: now };
    const { error } = await supabase.from("ledger_entries").update(patch).eq("id", e.id).in("status", ["pending", "blocked"]);
    if (error) throw error;
    if (off) continue;
    // Release non-commit steps that waited on this one.
    for (const d of all.filter((x) => x.run_id === e.run_id && x.depends_on === e.seq && x.status === "blocked" && !ids.has(x.id))) {
      const dp = d.preview as Preview | null;
      const { error: e2 } = await supabase.from("ledger_entries").update(unblockedStatus(dp?.blocked_by, true, !!dp?.saved_scope)).eq("id", d.id);
      if (e2) throw e2;
    }
  }
  if (scope && include.has(scope.invite.id) && !declined.has(scope.invite.seq)) {
    const v = (scope.invite.preview as Preview).scope!;
    const rule: Rule = { key: SCOPE_KEY("invites"), label: `Send invites without asking while recipients (${v.recipients}) and message match`, kind: "scope", value: v };
    const rules = [...scope.contract.rules.filter((r) => r.key !== rule.key), rule];
    const { error } = await supabase.from("contracts").update({ rules: rules as never }).eq("user_id", scope.contract.user_id);
    if (error) throw error;
  }
}

/** Save a scoped approval directly from the latest approved invite (Status suggestion). */
export async function saveScopeFrom(invite: Entry, contract: ContractRow) {
  const v = (invite.preview as Preview).scope!;
  const rule: Rule = { key: SCOPE_KEY("invites"), label: `Send invites without asking while recipients (${v.recipients}) and message match`, kind: "scope", value: v };
  const { error } = await supabase.from("contracts").update({ rules: [...contract.rules.filter((r) => r.key !== rule.key), rule] as never }).eq("user_id", contract.user_id);
  if (error) throw error;
}

/** Declined steps in a run that still wait for "what should happen instead?". */
export const awaitingAlternative = (e: Entry) => e.status === "declined" && !e.resolution;

/** Pick another option for a declined step: recorded as YOU CHOSE, then the run is re-planned. */
export async function chooseAlternative(declined: Entry, alt: Alternative, contract: ContractRow, all: Entry[]) {
  const step = all.find((x) => x.run_id === declined.run_id && x.criterion === alt.key && x.status !== "superseded");
  const rule: Rule = { key: alt.key, label: `Use ${alt.value} instead of “${step?.default_label ?? (alt.kind === "venue" ? "the agent's venue pick" : "the earliest open weekend")}”`, kind: "override", value: alt.value };
  const { error } = await supabase.from("contracts").update({ rules: [...contract.rules.filter((r) => r.key !== rule.key), rule] as never }).eq("user_id", contract.user_id);
  if (error) throw error;
  if (step) await supabase.from("ledger_entries").update({ resolution: `override:${alt.value}`, decided_at: new Date().toISOString() }).eq("id", step.id);
  // The declined card is replaced by a fresh one built on the new choice.
  const { error: e2 } = await supabase.from("ledger_entries").update({ status: "superseded", resolution: `replaced:${alt.value}` }).eq("id", declined.id);
  if (e2) throw e2;
  return replanRun({ data: { run_id: declined.run_id } });
}

/** "Stop the run here": the only path that cancels steps depending on the declined one. */
export async function stopRun(declined: Entry, all: Entry[]) {
  const run = all.filter((x) => x.run_id === declined.run_id && x.status !== "superseded");
  const nodes = run.map((x) => ({ seq: x.seq, inputs: x.inputs, depends_on: x.depends_on }));
  const down = run.filter((x) => (x.status === "blocked" || x.status === "pending") && upstreamOf(x.seq, nodes).includes(declined.seq));
  const now = new Date().toISOString();
  if (down.length) {
    const { error } = await supabase.from("ledger_entries").update({ status: "cancelled", source: "user", decided_at: now }).in("id", down.map((d) => d.id));
    if (error) throw error;
  }
  const { error } = await supabase.from("ledger_entries").update({ resolution: "stopped" }).eq("id", declined.id);
  if (error) throw error;
}

/**
 * Use another option for a step (budget split, venue, dates, or settling the agent conflict).
 * Just this run: recorded on the step row; as rule: also added to the contract. Returns an undo.
 */
export async function applyChoice(step: Entry, value: string, asRule: boolean, contract: ContractRow, all: Entry[]) {
  const key = step.criterion!;
  if (asRule) {
    const rule: Rule = { key, label: `Use ${value} instead of “${step.default_label ?? key}”`, kind: "override", value };
    const { error } = await supabase.from("contracts").update({ rules: [...contract.rules.filter((r) => r.key !== key), rule] as never }).eq("user_id", contract.user_id);
    if (error) throw error;
  }
  const { error } = await supabase.from("ledger_entries").update({ resolution: `override:${value}`, decided_at: new Date().toISOString() }).eq("id", step.id);
  if (error) throw error;
  const r = await replanRun({ data: { run_id: step.run_id } });
  const before = new Map(all.map((x) => [x.id, x]));
  async function undo() {
    if (r.inserted.length) await supabase.from("ledger_entries").delete().in("id", r.inserted);
    for (const id of r.superseded) { const o = before.get(id); if (o) await supabase.from("ledger_entries").update({ status: o.status, resolution: o.resolution }).eq("id", id); }
    await supabase.from("ledger_entries").update({ resolution: step.resolution, decided_at: step.decided_at }).eq("id", step.id);
    if (asRule) await supabase.from("contracts").update({ rules: contract.rules as never }).eq("user_id", contract.user_id);
  }
  return { ...r, undo };
}
