import { createServerFn } from "@tanstack/react-start";

/** Fresh, private demo account per visitor so nobody sees another visitor's runs. */
export const createDemoSandbox = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const id = crypto.randomUUID();
  const email = `demo-${id}@demo.cosign.app`;
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  const password = btoa(String.fromCharCode(...bytes)) + "aA1!";
  const { error } = await supabaseAdmin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { display_name: "Demo lead", team: "Demo team" } });
  if (error) throw new Error(error.message);
  return { email, password };
});
