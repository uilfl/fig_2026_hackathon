export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      contract_versions: {
        Row: {
          diff: Json
          id: string
          signed_at: string
          snapshot: Json
          user_id: string
          version: number
        }
        Insert: {
          diff?: Json
          id?: string
          signed_at?: string
          snapshot: Json
          user_id: string
          version: number
        }
        Update: {
          diff?: Json
          id?: string
          signed_at?: string
          snapshot?: Json
          user_id?: string
          version?: number
        }
        Relationships: []
      }
      contracts: {
        Row: {
          budget_cap: number
          goal: string
          headcount: number
          rules: Json
          triggers: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          budget_cap?: number
          goal?: string
          headcount?: number
          rules?: Json
          triggers?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          budget_cap?: number
          goal?: string
          headcount?: number
          rules?: Json
          triggers?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ledger_entries: {
        Row: {
          action: string
          agent: string
          created_at: string
          criteria: Json
          criterion: string | null
          decided_at: string | null
          default_key: string | null
          default_label: string | null
          depends_on: number | null
          filtered_out: Json
          id: string
          inputs: Json
          kind: string
          options_considered: Json
          preview: Json | null
          rationale: string
          resolution: string | null
          run_id: string
          seq: number
          source: string
          status: string
          user_id: string
        }
        Insert: {
          action: string
          agent: string
          created_at?: string
          criteria?: Json
          criterion?: string | null
          decided_at?: string | null
          default_key?: string | null
          default_label?: string | null
          depends_on?: number | null
          filtered_out?: Json
          id?: string
          inputs?: Json
          kind: string
          options_considered?: Json
          preview?: Json | null
          rationale?: string
          resolution?: string | null
          run_id: string
          seq: number
          source: string
          status?: string
          user_id: string
        }
        Update: {
          action?: string
          agent?: string
          created_at?: string
          criteria?: Json
          criterion?: string | null
          decided_at?: string | null
          default_key?: string | null
          default_label?: string | null
          depends_on?: number | null
          filtered_out?: Json
          id?: string
          inputs?: Json
          kind?: string
          options_considered?: Json
          preview?: Json | null
          rationale?: string
          resolution?: string | null
          run_id?: string
          seq?: number
          source?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          id: string
          team: string
        }
        Insert: {
          created_at?: string
          display_name?: string
          id: string
          team?: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          team?: string
        }
        Relationships: []
      }
      shared_receipts: {
        Row: {
          created_at: string
          id: string
          run_id: string
          summary: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          run_id: string
          summary: Json
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          run_id?: string
          summary?: Json
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_shared_receipt: { Args: { _id: string }; Returns: Json }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
