import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useDemo } from "@/hooks/use-demo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [
    { title: "Sign in — Cosign" }, { name: "description", content: "Sign in to your Cosign responsibility ledger." },
    { property: "og:title", content: "Sign in — Cosign" }, { property: "og:description", content: "Sign in to your Cosign responsibility ledger." },
  ] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [f, setF] = useState({ email: "", password: "", display_name: "", team: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email: f.email, password: f.password });
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      navigate({ to: "/contract" });
    } else {
      const { data, error } = await supabase.auth.signUp({
        email: f.email, password: f.password,
        options: { emailRedirectTo: window.location.origin + "/contract", data: { display_name: f.display_name, team: f.team } },
      });
      setBusy(false);
      if (error) { toast.error(error.message); return; }
      if (data.session) navigate({ to: "/contract" });
      else setSent(true);
    }
  }

  const demo = useDemo();

  return (
    <div className="grid min-h-screen place-items-center px-6">
      <div className="w-full max-w-sm">
        <h1 className="text-5xl">Cosign<span className="text-accent">.</span></h1>
        <p className="mt-2 text-muted-foreground">{mode === "in" ? "Sign in to your ledger." : "Create your ledger."}</p>
        <Button type="button" variant="stamp" size="lg" className="mt-8 w-full" disabled={busy || demo.busy} onClick={demo.start}>{demo.busy ? "Setting up your sandbox…" : "Try the demo"}</Button>
        <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">A fresh sandbox each time — no one sees your runs.</p>
        <div className="my-6 flex items-center gap-3 font-mono text-[10px] uppercase text-muted-foreground"><span className="h-px flex-1 bg-border" />or use your account<span className="h-px flex-1 bg-border" /></div>
        {sent ? (
          <p className="mt-8 border border-border bg-card p-4 text-sm">Check your email to confirm your account, then sign in.</p>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            {mode === "up" && (
              <>
                <div><Label htmlFor="n">Your name</Label><Input id="n" required value={f.display_name} onChange={(e) => setF({ ...f, display_name: e.target.value })} /></div>
                <div><Label htmlFor="t">Team</Label><Input id="t" required value={f.team} onChange={(e) => setF({ ...f, team: e.target.value })} /></div>
              </>
            )}
            <div><Label htmlFor="e">Email</Label><Input id="e" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
            <div><Label htmlFor="p">Password</Label><Input id="p" type="password" minLength={6} required value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
            <Button className="w-full" disabled={busy}>{mode === "in" ? "Sign in" : "Create account"}</Button>
          </form>
        )}
        <button className="mt-4 text-sm text-muted-foreground underline" onClick={() => { setMode(mode === "in" ? "up" : "in"); setSent(false); }}>
          {mode === "in" ? "New here? Create an account" : "Have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}
