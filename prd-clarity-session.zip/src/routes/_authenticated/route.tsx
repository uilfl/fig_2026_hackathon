import { createFileRoute, Outlet, redirect, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppHeader } from "@/components/AppHeader";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: Layout,
});

function Layout() {
  const wide = useRouterState({ select: (s) => s.location.pathname === "/run" });
  return (
    <div className="min-h-screen md:flex">
      <AppHeader />
      <main className={`w-full min-w-0 flex-1 px-6 py-10 ${wide ? "" : "mx-auto max-w-[1120px]"}`}><Outlet /></main>
    </div>
  );
}
