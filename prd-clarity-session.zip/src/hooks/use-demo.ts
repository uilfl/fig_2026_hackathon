import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { createDemoSandbox } from "@/lib/demo.functions";

/** "Try the demo": a fresh sandbox account per visit, then straight to the contract. */
export function useDemo() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  async function start() {
    setBusy(true);
    try {
      const creds = await createDemoSandbox();
      const { error } = await supabase.auth.signInWithPassword(creds);
      if (error) throw error;
      navigate({ to: "/contract" });
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not start the demo"); setBusy(false); }
  }
  return { start, busy };
}
